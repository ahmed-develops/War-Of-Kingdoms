require "extern"
require "CCBReaderLoad"
require "common"

GoldExchangeLuaCell  = GoldExchangeLuaCell or {}
ccb["GoldExchangeLuaCell"] = GoldExchangeLuaCell

GoldExchangeCell = class("GoldExchangeCell",
	function()
        return CCLayer:create() 
	end
)
GoldExchangeCell.__index = GoldExchangeCell
function GoldExchangeCell:create(path,params,popup_item)
	local node = GoldExchangeCell.new()
	node:init(path,params,popup_item)
	return node
end
function GoldExchangeCell:init(path,params,popup_item)
    self.rootPath = path
    self.data = params
    self.dataCount = table.getn(self.data)
    self.popup_item = popup_item
    print ("GoldExchangeCell:init dataCount:" .. self.dataCount)
    local  proxy = CCBProxy:create()
    local ccbiUrl = ""
    if(popup_item == "king") then
        ccbiUrl = self.rootPath .. "/ccbi/GoldExchangekingLuaCell.ccbi"
    elseif popup_item == "city_fund" then
        ccbiUrl = self.rootPath .. "/ccbi/GoldExchangecity_fundLuaCell.ccbi"
    else
        ccbiUrl = self.rootPath .. "/ccbi/GoldExchangeLuaCell.ccbi"
        end
	local  node  = CCBReaderLoad(ccbiUrl,proxy,true,"GoldExchangeLuaCell")
    if(nil == node) then
        return
    end
    print ("popup_item:" .. popup_item)
    print ("ccbiUrl:" .. ccbiUrl)

    local layer = tolua.cast(node,"CCLayer")
    print "GoldExchangeCell:init"
    if nil ~= GoldExchangeLuaCell["m_itemNode1"] then
        self.m_itemNode1 = tolua.cast(GoldExchangeLuaCell["m_itemNode1"],"CCLayer")
        self.m_itemNode1:setVisible(false)
    end
    if nil ~= GoldExchangeLuaCell["m_itemNode2"] then
        self.m_itemNode2 = tolua.cast(GoldExchangeLuaCell["m_itemNode2"],"CCLayer")
        self.m_itemNode2:setVisible(false)
    end
    if nil ~= GoldExchangeLuaCell["m_itemNode3"] then
        self.m_itemNode3 = tolua.cast(GoldExchangeLuaCell["m_itemNode3"],"CCLayer")
        self.m_itemNode3:setVisible(false)
    end

    self.picNodeList = {}
    if self.dataCount > 0 then
        local d = self.data[1];
        if nil ~= self.m_itemNode1 then
            self.m_itemNode1:setVisible(true)

            if nil ~= GoldExchangeLuaCell["m_picNode1"] then
                self.m_picNode1 = tolua.cast(GoldExchangeLuaCell["m_picNode1"],"CCLayer")
                if nil ~= self.m_picNode1 then
                    local nameLabel = CCLabelTTF:create()
                    local itemID = d[1]
                    LuaController:addItemIcon(self.m_picNode1,d[1],nameLabel)
                    d[itemID] = nameLabel:getString()
                    table.insert(self.picNodeList, self.m_picNode1)
                end
            end

            if nil ~= GoldExchangeLuaCell["m_numLabel1"] then
                self.m_numLabel1 = tolua.cast(GoldExchangeLuaCell["m_numLabel1"],"CCLabelTTF")
                if nil ~= self.m_numLabel1 then
                    local numStr = string.format(d[2])
                    self.m_numLabel1:setString(numStr)
                end
            end
        end
    end

    if self.dataCount > 1 then
        local d = self.data[2];
        if nil ~= self.m_itemNode2 then
            self.m_itemNode2:setVisible(true)

            if nil ~= GoldExchangeLuaCell["m_picNode2"] then
                self.m_picNode2 = tolua.cast(GoldExchangeLuaCell["m_picNode2"],"CCLayer")
                if nil ~= self.m_picNode2 then
                    local nameLabel = CCLabelTTF:create()
                    local itemID = d[1]
                    LuaController:addItemIcon(self.m_picNode2,d[1],nameLabel)
                    d[itemID] = nameLabel:getString()
                    table.insert(self.picNodeList, self.m_picNode2)
                end
            end

            if nil ~= GoldExchangeLuaCell["m_numLabel2"] then
                self.m_numLabel2 = tolua.cast(GoldExchangeLuaCell["m_numLabel2"],"CCLabelTTF")
                if nil ~= self.m_numLabel2 then
                    local numStr = string.format(d[2])
                    self.m_numLabel2:setString(numStr)
                end
            end
        end
    end

    if self.dataCount > 2 then
        local d = self.data[3];
        if nil ~= self.m_itemNode3 then
            self.m_itemNode3:setVisible(true)

            if nil ~= GoldExchangeLuaCell["m_picNode3"] then
                self.m_picNode3 = tolua.cast(GoldExchangeLuaCell["m_picNode3"],"CCLayer")
                if nil ~= self.m_picNode3 then
                    local nameLabel = CCLabelTTF:create()
                    local itemID = d[1]
                    LuaController:addItemIcon(self.m_picNode3,d[1],nameLabel)
                    d[itemID] = nameLabel:getString()
                    table.insert(self.picNodeList, self.m_picNode3)
                end
            end

            if nil ~= GoldExchangeLuaCell["m_numLabel3"] then
                self.m_numLabel3 = tolua.cast(GoldExchangeLuaCell["m_numLabel3"],"CCLabelTTF")
                if nil ~= self.m_numLabel3 then
                    local numStr = string.format(d[2])
                    self.m_numLabel3:setString(numStr)
                end
            end
        end
    end

    --[[
    if nil ~= GoldExchangeLuaCell["m_nameLabel"] then
        self.m_nameLabel = tolua.cast(GoldExchangeLuaCell["m_nameLabel"],"CCLabelTTF")
        if nil ~= self.m_nameLabel then
            self.m_nameLabel:setString("")
        end
    end
    if nil ~= GoldExchangeLuaCell["m_numLabel"] then
        self.m_numLabel = tolua.cast(GoldExchangeLuaCell["m_numLabel"],"CCLabelTTF")
        if nil ~= self.m_numLabel then
            local numStr = string.format(self.data[2])
            self.m_numLabel:setString(numStr)
        end
    end
    if nil ~= GoldExchangeLuaCell["m_iconNode"] then
    	self.m_iconNode = tolua.cast(GoldExchangeLuaCell["m_iconNode"],"CCLayerColor")
        if nil ~= self.m_iconNode then
            LuaController:addItemIcon(self.m_iconNode,self.data[1],self.m_nameLabel)
        end
    end
    ]]
    self:addChild(node)

    self:adjustIcon()
end

function GoldExchangeCell:getTouchData(x, y)

    for i = 1, #self.picNodeList do  
        local picNode =  self.picNodeList[i]
        local pos = picNode:getParent():convertToNodeSpace(ccp(x,y))
        local rect = picNode:boundingBox()
        if(rect:containsPoint(pos) == true) then
            print("cell touch inside")
            return self.data[i];
        end 
    end

    return nil
end

function GoldExchangeCell:adjustIcon()
    for i = 1, #self.picNodeList do  
        local picNode =  self.picNodeList[i]

        local i = 0
        for i = 0, picNode:getChildren():count()-1, 1 do
            local node = tolua.cast(picNode:getChildren():objectAtIndex(i),"CCNode")
            local width = node:getContentSize().width
            node:setScale(127/width)
            node:setPosition(127/2, 127/2)
        end
    end
end