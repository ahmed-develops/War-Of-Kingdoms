require "extern"
require "CCBReaderLoad"
require "common"

GoldExchangeLuaNewCell  = GoldExchangeLuaNewCell or {}
ccb["GoldExchangeLuaNewCell"] = GoldExchangeLuaNewCell

GoldExchangeNewCell = class("GoldExchangeNewCell",
	function()
        return CCLayer:create() 
	end
)
GoldExchangeNewCell.__index = GoldExchangeNewCell
function GoldExchangeNewCell:create(path,item,size,popup_item)
	local node = GoldExchangeNewCell.new()
	node:init(path,item,size,popup_item)
	return node
end
function GoldExchangeNewCell:init(path,item,size,popup_item)
    self.rootPath = path
    self.item = item
    self.size = size
    self.popup_item = popup_item
    local  proxy = CCBProxy:create()
    local  ccbiUrl = self.rootPath .. "/ccbi/GoldExchangeLuaNewCell.ccbi"
    local  node  = CCBReaderLoad(ccbiUrl,proxy,true,"GoldExchangeLuaNewCell")
    if(nil == node) then
        return
    end
    print ("popup_item:" .. popup_item)
    print ("ccbiUrl:" .. ccbiUrl)

    local layer = tolua.cast(node,"CCLayer")
    print "GoldExchangeNewCell:init"
    if nil ~= GoldExchangeLuaNewCell["m_itemNode"] then
        self.m_itemNode = tolua.cast(GoldExchangeLuaNewCell["m_itemNode"],"CCLayer")
        self.m_itemNode:setScale(size/150)
        --self.m_itemNode:setVisible(true)
    end

    if nil ~= GoldExchangeLuaNewCell["m_picNode"] then
        self.m_picNode = tolua.cast(GoldExchangeLuaNewCell["m_picNode"],"CCLayer")
        if nil ~= self.m_picNode then
            local nameLabel = CCLabelTTF:create()
            LuaController:addItemIcon(self.m_picNode,self.item[1],nameLabel)
            item[item[1]] = nameLabel:getString()
        end
    end

    if nil ~= GoldExchangeLuaNewCell["m_numLabel"] then
        self.m_numLabel = tolua.cast(GoldExchangeLuaNewCell["m_numLabel"],"CCLabelTTF")
        if nil ~= self.m_numLabel then
            local numStr = string.format(item[2])
            self.m_numLabel:setString(numStr)
        end
    end
    
    self:addChild(node)
    print "GoldExchangeNewCell:end"
end

function GoldExchangeNewCell:getTouchData(x, y)
    local pos = self.m_picNode:getParent():convertToNodeSpace(ccp(x,y))
    local rect = self.m_picNode:boundingBox()
    if(rect:containsPoint(pos) == true) then
        print("cell touch inside")
        return self.item;
    end 

    return nil
end
